#pragma once

#include "resource.h"
#include "Texture.h"

extern int g_nClientWidth;
extern int g_nClientHeight;
extern bool g_bIsActive;
extern Texture* g_Texture;