#pragma once

void InitFrame(void);
void UpdateFrame(void);
